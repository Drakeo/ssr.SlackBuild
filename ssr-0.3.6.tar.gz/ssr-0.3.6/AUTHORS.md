SimpleScreenRecorder contributors
=================================

Programming
-----------

- Maarten Baert
- Boran Car (GLInject hotkey workaround)
- Dubslow (profiles)
- Dmitry Kostenko ('simpleui' patches)

Graphics
--------

- David Revoy (icon)
- Mrallowski (original camera lens from openclipart.org)

Translations
------------

- Arabic: Abdulla
- Bulgarian: Svetoslav Sashkov
- Czech: Radek Steiger
- German: Manuel Schömburg
- Greek: Nick Thom
- Spanish: Dani Rodríguez
- French: Mario Roger
- Hebrew: GreenLunar
- Hungarian: ViBE
- Italian: Bersil
- Japanese: Tou Omiya
- Dutch: Maarten Baert
- Polish: Szamanx0
- Brazilian Portuguese: Paulo Milliet Roque, Rafael Ferreira
- Russian: Dima Koshel
- Swedish: Åke Engelbrektson
- Ukrainian: Rom Gyrfalco
- Simplified Chinese: Weitian Leung
- Traditional Chinese: Estea Chen
